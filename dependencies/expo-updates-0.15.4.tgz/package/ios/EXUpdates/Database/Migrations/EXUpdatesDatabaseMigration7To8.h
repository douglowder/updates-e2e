//  Copyright © 2021 650 Industries. All rights reserved.

#import <EXUpdates/EXUpdatesDatabaseMigration.h>

NS_ASSUME_NONNULL_BEGIN

@interface EXUpdatesDatabaseMigration7To8 : NSObject <EXUpdatesDatabaseMigration>

@end

NS_ASSUME_NONNULL_END
